/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*!40000 ALTER TABLE `tbl_global_category` DISABLE KEYS */;
INSERT INTO `tbl_global_category` (`global_id`, `name`) VALUES
	(1, 'Rechnungswesen/Finanzen'),
	(2, 'Administration/Sachbearbeitung'),
	(3, 'Immobilien'),
	(4, 'Handwerk'),
	(5, 'Geschäftsleitung/Strategisches Management'),
	(6, 'Design & Gestaltung'),
	(7, 'Customer Service/Kundenbetreuung'),
	(8, 'Redaktion/Dokumentation'),
	(9, 'Ingenieurwesen/Entwicklung und Konstruktion'),
	(10, 'Hotel und Gastronomie'),
	(11, 'Personalwesen'),
	(12, 'Instandhaltung'),
	(13, 'IT/Informationstechnologie'),
	(14, 'Recht'),
	(15, 'Logistik und Transport'),
	(16, 'Marketing/Produkt'),
	(17, 'Medizin und Gesundheit'),
	(18, 'sonstige Berufe'),
	(19, 'Produktion'),
	(20, 'Projektmanagement'),
	(21, 'Qualitätswesen'),
	(22, 'Naturwissenschaftliche Forschung'),
	(23, 'Vertrieb/Verkauf'),
	(24, 'Sicherheit/Zivilschutz'),
	(25, 'Aus- und Weiterbildung'),
    (26, 'Controlling'),
    (27, 'Landwirtschaft/Forstwirtschaft/Fischerei'),
    (28, 'Revision'),
    (29, 'Wirtschaftsprüfung'),
    (30, 'Banking'),
    (31, 'Beratung'),
    (32, 'Architektur'),
    (33, 'Erziehung/Bildung'),
    (34, 'Elektrik/Elektronik/Elektrotechnik'),
    (35, 'Aushilfe'),
    (36, 'Versicherung'),
    (37, 'Einkauf'),
    (38, 'Medienproduktion/-technik'),
    (39, 'Journalismus'),
    (40, 'Öffentlichkeitsarbeit / PR'),
    (41, 'Organisation'),
    (42, 'Office Management'),
    (43, 'Sozialwesen'),
    (44, 'Technischer Beruf');
/*!40000 ALTER TABLE `tbl_global_category` ENABLE KEYS */;	

/*!40000 ALTER TABLE `tbl_global_classification` DISABLE KEYS */;
INSERT INTO `tbl_global_classification` (`global_id`, `name`) VALUES
	(1, 'Festanstellung'),
	(2, 'Freelance'),
	(3, 'Ausbildung'),
	(4, 'Trainee'),
	(5, 'Praktikum'),
	(6, 'Hilfskraft'),
	(9, 'Geringfügige Beschäftigung/Minijob'),
	(10, 'Künstler:in'),
	(11, 'Selbständig')
    (12, 'Werkstudent:in'),
    (13, 'Verbeamtet'),
    (14, 'Abschlussarbeit'),
    (15, 'Befristet'),
    (16, 'Duales Studium');
/*!40000 ALTER TABLE `tbl_global_classification` ENABLE KEYS */;	

/*!40000 ALTER TABLE `tbl_global_schedule` DISABLE KEYS */;
INSERT INTO `tbl_global_schedule` (`global_id`, `name`) VALUES
	(1, 'Vollzeit'),
	(5, 'Teilzeit - Vormittag'),
	(6, 'Teilzeit - Nachmittag'),
	(7, 'Teilzeit - Abend'),
	(8, 'Teilzeit - flexibel'),
	(9, 'Heimarbeit'),
	(11, 'Schicht / Nacht / Wochenende'),
	(12, 'Vollzeit oder Teilzeit');
/*!40000 ALTER TABLE `tbl_global_schedule` ENABLE KEYS */;	

/*!40000 ALTER TABLE `tbl_global_seniority` DISABLE KEYS */;
INSERT INTO `tbl_global_seniority` (`global_id`, `name`) VALUES
	(1, 'Schüler:in'),
	(2, 'Student:in'),
	(3, 'Absolvent:in'),
	(4, 'Berufseinstieg'),
	(5, 'Mit Berufserfahrung'),
	(6, 'Manager:in'),
	(7, 'Direktor:in'),
	(8, 'Vorstand/Geschäftsführung');
/*!40000 ALTER TABLE `tbl_global_seniority` ENABLE KEYS */;


/*!40000 ALTER TABLE `tbl_i18n` DISABLE KEYS */;
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name',  1, 'en_GB', 'Accounting/Finance');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name',  2, 'en_GB', 'Administration/Clerical');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name',  3, 'en_GB', 'Property Manager - Real Estate Agent');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name',  4, 'en_GB', 'Craftsmanship');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name',  5, 'en_GB', 'Executive/Strategic Management');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name',  6, 'en_GB', 'Design & Styling');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name',  7, 'en_GB', 'Customer Service');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name',  8, 'en_GB', 'Editorial/Documentation');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name',  9, 'en_GB', 'Engineering/Development and Construction');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 10, 'en_GB', 'Hotel and Gastronomy');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 11, 'en_GB', 'Human Resources');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 12, 'en_GB', 'Maintenance');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 13, 'en_GB', 'IT/Information Technology');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 14, 'en_GB', 'Legal');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 15, 'en_GB', 'Logistics and Transportation');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 16, 'en_GB', 'Marketing/Product');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 17, 'en_GB', 'Medical and Health');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 18, 'en_GB', 'Other Professions');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 19, 'en_GB', 'Production');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 20, 'en_GB', 'Project Management');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 21, 'en_GB', 'Quality Management');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 22, 'en_GB', 'Scientific Research');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 23, 'en_GB', 'Sales');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 24, 'en_GB', 'Security/Civil Protection');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 25, 'en_GB', 'Education and Training');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 26, 'en_GB', 'Controlling');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 27, 'en_GB', 'Agriculture');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 28, 'en_GB', 'Internal auditing');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 29, 'en_GB', 'Auditing');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 30, 'en_GB', 'Banking');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 31, 'en_GB', 'Consulting');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 32, 'en_GB', 'Architecture');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 33, 'en_GB', 'Education');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 34, 'en_GB', 'Electric');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 35, 'en_GB', 'Helper');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 36, 'en_GB', 'Insurance');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 37, 'en_GB', 'Procurement');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 38, 'en_GB', 'Media production');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 39, 'en_GB', 'Journalism');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 40, 'en_GB', 'Public relations');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 41, 'en_GB', 'Organization');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 42, 'en_GB', 'Office management');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 43, 'en_GB', 'Social services');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_category', 'name', 44, 'en_GB', 'Technical');

INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 1, 'en_GB', 'Permanent Employment');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 2, 'en_GB', 'Freelancer');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 3, 'en_GB', 'Apprenticeship');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 4, 'en_GB', 'Trainee');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 5, 'en_GB', 'Internship/Student Assistant');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 6, 'en_GB', 'Assistant');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 9, 'en_GB', 'Marginal Employment/Mini Job');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 10, 'en_GB', 'Artist');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 11, 'en_GB', 'Self-employed');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 12, 'en_GB', 'Working student');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 13, 'en_GB', 'Civil servant');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 14, 'en_GB', 'Thesis');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 15, 'en_GB', 'Fixed term');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_classification', 'name', 16, 'en_GB', 'Dual study program');

INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_schedule', 'name', 1, 'en_GB', 'Full-time');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_schedule', 'name', 5, 'en_GB', 'Part-time - Morning');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_schedule', 'name', 6, 'en_GB', 'Part-time - Afternoon');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_schedule', 'name', 7, 'en_GB', 'Part-time - Evening');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_schedule', 'name', 8, 'en_GB', 'Part-time - Flexible');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_schedule', 'name', 9, 'en_GB', 'Remote Work');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_schedule', 'name', 11, 'en_GB', 'Shift / night / weekend');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_schedule', 'name', 12, 'en_GB', 'Full-time or part-time');

INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_seniority', 'name', 1, 'en_GB', 'Pupils');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_seniority', 'name', 2, 'en_GB', 'Student');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_seniority', 'name', 3, 'en_GB', 'Graduate');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_seniority', 'name', 4, 'en_GB', 'Entry Level');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_seniority', 'name', 5, 'en_GB', 'Experienced');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_seniority', 'name', 6, 'en_GB', 'Manager');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_seniority', 'name', 7, 'en_GB', 'Director');
INSERT INTO `tbl_i18n` (`model`, `field`, `key`, `locale`, `translation`) VALUES ('global_seniority', 'name', 8, 'en_GB', 'Executive');
/*!40000 ALTER TABLE `tbl_i18n` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;	